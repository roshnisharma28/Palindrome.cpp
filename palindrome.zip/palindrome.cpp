#include<iostream>
using namespace std;
void ispalindrome(string& str,int i,int j){
    
    //base case
    if(i>j){
        return;
    }
    swap(str[i++],str[j--]);
    ispalindrome(str,i,j);


}
int main(){
    string check;
    check="apple";
    string copy=check;
    cout<<endl;
    ispalindrome(check,0,check.length()-1);
    cout<<check<<endl;
    if(check==copy){
        cout<<"The string is palindrome"<<endl;
    }
    else{
        cout<<"Not palindrome"<<endl;
    }
    
}